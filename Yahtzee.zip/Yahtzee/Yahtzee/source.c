/*	Name: JBEustice
*	Year: 2013
*	Description: a game of yahtzee between 2 players
*/

#include "header.h"

// counts the number of 1s, 2s, 3s, 4s, 5s, 6s and returns values to main via pointers
void die_count(int die1, int die2, int die3, int die4, int die5, int *c1, int *c2, int *c3, int *c4, int *c5, int *c6)
{
	int count1 = 0, count2 = 0, count3 = 0, count4 = 0, count5 = 0, count6 = 0;
	if (die1 == 1)
		count1++;
	else if (die1 == 2)
		count2++;
	else if (die1 == 3)
		count3++;
	else if (die1 == 4)
		count4++;
	else if (die1 == 5)
		count5++;
	else
		count6++;
	//--------------
	if (die2 == 1)
		count1++;
	else if (die2 == 2)
		count2++;
	else if (die2 == 3)
		count3++;
	else if (die2 == 4)
		count4++;
	else if (die2 == 5)
		count5++;
	else
		count6++;
	//--------------
	if (die3 == 1)
		count1++;
	else if (die3 == 2)
		count2++;
	else if (die3 == 3)
		count3++;
	else if (die3 == 4)
		count4++;
	else if (die3 == 5)
		count5++;
	else
		count6++;
	//--------------
	if (die4 == 1)
		count1++;
	else if (die4 == 2)
		count2++;
	else if (die4 == 3)
		count3++;
	else if (die4 == 4)
		count4++;
	else if (die4 == 5)
		count5++;
	else
		count6++;
	//--------------
	if (die5 == 1)
		count1++;
	else if (die5 == 2)
		count2++;
	else if (die5 == 3)
		count3++;
	else if (die5 == 4)
		count4++;
	else if (die5 == 5)
		count5++;
	else
		count6++;
	//--------------
	*c1 = count1;
	*c2 = count2;
	*c3 = count3;
	*c4 = count4;
	*c5 = count5;
	*c6 = count6;
	return;
}

// adds up all die of the specified value and returns the score
int total_digits(int number, int count1, int count2, int count3, int count4, int count5, int count6)
{
	int score = 0;
	if (number == 1)
		score = count1 * 1;
	else if (number == 2)
		score = count2 * 2;
	else if (number == 3)
		score = count3 * 3;
	else if (number == 4)
		score = count4 * 4;
	else if (number == 5)
		score = count5 * 5;
	else
		score = count6 * 6;
	return score;
}

// this is the loop that goes through the 13 turns per player
void start(int *sum1p, int *sum2p, int *sum3p, int *sum4p, int *sum5p, int *sum6p,
	int *threep, int *fourp, int *fullhousep, int *smallstrp, int *largestrp, int *yahtzeep, int *chancep,
	int *sum1_p, int *sum2_p, int *sum3_p, int *sum4_p, int *sum5_p, int *sum6_p,
	int *three_p, int *four_p, int *fullhouse_p, int *smallstr_p, int *largestr_p, int *yahtzee_p, int *chance_p)
{
	int turn = 0;
	for (turn = 1; turn<27; turn++)
	{
		int d1 = 0, d2 = 0, d3 = 0, d4 = 0, d5 = 0, player = 0;
		srand((unsigned int)time(NULL));
		player = (turn + 2) % 2;
		if (player == 1)
		{
			printf("Player 1's turn\n");
			roll_turns(&d1, &d2, &d3, &d4, &d5);
			chose_score(sum1p, sum2p, sum3p, sum4p, sum5p, sum6p, threep, fourp, fullhousep, smallstrp, largestrp, yahtzeep, chancep, &d1, &d2, &d3, &d4, &d5);
		}
		else
		{
			printf("Player 2's turn\n");
			roll_turns(&d1, &d2, &d3, &d4, &d5);
			chose_score(sum1_p, sum2_p, sum3_p, sum4_p, sum5_p, sum6_p, three_p, four_p, fullhouse_p, smallstr_p, largestr_p, yahtzee_p, chance_p, &d1, &d2, &d3, &d4, &d5);
		}
	}
	system("cls");
	printf("Player 1's scores\n");
	print_scores(sum1p, sum2p, sum3p, sum4p, sum5p, sum6p, threep, fourp, fullhousep, smallstrp, largestrp, yahtzeep, chancep);
	printf("\nPlayer 2's scores\n");
	print_scores(sum1_p, sum2_p, sum3_p, sum4_p, sum5_p, sum6_p, three_p, four_p, fullhouse_p, smallstr_p, largestr_p, yahtzee_p, chance_p);
	printf("Press a key and Enter to continue . . .");
	while (getchar() == '\n');

}

// rolls 5 die and sends back value via pointers
void roll_5(int *die1, int *die2, int *die3, int *die4, int *die5)
{
	*die1 = roll_die();
	*die2 = roll_die();
	*die3 = roll_die();
	*die4 = roll_die();
	*die5 = roll_die();
}

// rolls 1 dice and returns value
int roll_die(void)
{
	int die_value = 0;
	die_value = (rand() % 6) + 1;
	return die_value;
}

// prints the values of all 5 die
void print_5(int die1, int die2, int die3, int die4, int die5)
{
	printf("Die 1: %d\n", die1);
	printf("Die 2: %d\n", die2);
	printf("Die 3: %d\n", die3);
	printf("Die 4: %d\n", die4);
	printf("Die 5: %d\n", die5);
}

// starts the program by displaying options screen and getting choice
int run(void)
{
	int option = 0, valid = 0;
	do
	{
		display_menu();
		option = get_option();
		valid = valid_option(option);
		system("cls");
	} while (!valid);
	return option;
}

// gets option from options screen
int get_option(void)
{
	int option = 0;
	scanf("%d", &option);
	return option;
}

// validates option choice
int valid_option(int option)
{
	int flag = 0;
	if ((option >= 1) && (option <= 3))
		flag = 1;
	return flag;
}

// displays menu
void display_menu(void)
{
	printf("1. Print game rules.\n");
	printf("2. Play game.\n");
	printf("3. Exit.\n");
}

// rolls die up to 3 times for each player's turn
void roll_turns(int *die1, int *die2, int *die3, int *die4, int *die5)
{
	int roll1 = 0, roll2 = 0, roll3 = 0, roll4 = 0, roll5 = 0;
	char re_roll = 0;
	char r1 = '\0', r2 = '\0', r3 = '\0', r4 = '\0', r5 = '\0';

	printf("Press a key and Enter to roll\n");
	while (getchar() == '\n');
	system("cls");

	roll_5(&roll1, &roll2, &roll3, &roll4, &roll5);
	print_5(roll1, roll2, roll3, roll4, roll5);
	printf("Would you like to use these die for one of the game combinations (y/n)?\n");
	scanf(" %c", &re_roll);

	if (re_roll == 'n')
	{
		printf("Reroll die 1 (y/n)?");
		scanf(" %c", &r1);
		printf("Reroll die 2 (y/n)?");
		scanf(" %c", &r2);
		printf("Reroll die 3 (y/n)?");
		scanf(" %c", &r3);
		printf("Reroll die 4 (y/n)?");
		scanf(" %c", &r4);
		printf("Reroll die 5 (y/n)?");
		scanf(" %c", &r5);
		system("cls");
		if (r1 == 'y')
			roll1 = roll_die();
		if (r2 == 'y')
			roll2 = roll_die();
		if (r3 == 'y')
			roll3 = roll_die();
		if (r4 == 'y')
			roll4 = roll_die();
		if (r5 == 'y')
			roll5 = roll_die();
		print_5(roll1, roll2, roll3, roll4, roll5);
		printf("Would you like to use these die for one of the game combinations (y/n)?\n");
		scanf(" %c", &re_roll);

		if (re_roll == 'n')
		{
			printf("Reroll die 1 (y/n)?");
			scanf(" %c", &r1);
			printf("Reroll die 2 (y/n)?");
			scanf(" %c", &r2);
			printf("Reroll die 3 (y/n)?");
			scanf(" %c", &r3);
			printf("Reroll die 4 (y/n)?");
			scanf(" %c", &r4);
			printf("Reroll die 5 (y/n)?");
			scanf(" %c", &r5);
			system("cls");
			if (r1 == 'y')
				roll1 = roll_die();
			if (r2 == 'y')
				roll2 = roll_die();
			if (r3 == 'y')
				roll3 = roll_die();
			if (r4 == 'y')
				roll4 = roll_die();
			if (r5 == 'y')
				roll5 = roll_die();
			print_5(roll1, roll2, roll3, roll4, roll5);
		}
	}
	*die1 = roll1;
	*die2 = roll2;
	*die3 = roll3;
	*die4 = roll4;
	*die5 = roll5;
}

// sendds back score via pointers to choice of game category
void chose_score(int *sum1p, int *sum2p, int *sum3p, int *sum4p, int *sum5p, int *sum6p,
	int *threep, int *fourp, int *fullhousep, int *smallstrp, int *largestrp, int *yahtzeep, int *chancep,
	int *d1, int *d2, int *d3, int *d4, int *d5)
{
	int c1 = 0, c2 = 0, c3 = 0, c4 = 0, c5 = 0, c6 = 0;
	int dd1 = 0, dd2 = 0, dd3 = 0, dd4 = 0, dd5 = 0;
	int choice = 0, score = 0;
	dd1 = *d1;
	dd2 = *d2;
	dd3 = *d3;
	dd4 = *d4;
	dd5 = *d5;

	printf("Which game combination would you like to use?\n");
	if (*sum1p == -1)
		printf("1. Sum of 1's\n");
	if (*sum2p == -1)
		printf("2. Sum of 2's\n");
	if (*sum3p == -1)
		printf("3. Sum of 3's\n");
	if (*sum4p == -1)
		printf("4. Sum of 4's\n");
	if (*sum5p == -1)
		printf("5. Sum of 5's\n");
	if (*sum6p == -1)
		printf("6. Sum of 6's\n");
	if (*threep == -1)
		printf("7. Three-of-a-kind\n");
	if (*fourp == -1)
		printf("8. Four-of-a-kind\n");
	if (*fullhousep == -1)
		printf("9. Full house\n");
	if (*smallstrp == -1)
		printf("10. Small straight\n");
	if (*largestrp == -1)
		printf("11. Large straight\n");
	if (*yahtzeep == -1)
		printf("12. Yahtzee\n");
	if (*chancep == -1)
		printf("13. Chance\n");
	scanf("%d", &choice);
	system("cls");

	die_count(dd1, dd2, dd3, dd4, dd5, &c1, &c2, &c3, &c4, &c5, &c6);
	if (choice == 1)
		*sum1p = total_digits(1, c1, c2, c3, c4, c5, c6);
	if (choice == 2)
		*sum2p = total_digits(2, c1, c2, c3, c4, c5, c6);
	if (choice == 3)
		*sum3p = total_digits(3, c1, c2, c3, c4, c5, c6);
	if (choice == 4)
		*sum4p = total_digits(4, c1, c2, c3, c4, c5, c6);
	if (choice == 5)
		*sum5p = total_digits(5, c1, c2, c3, c4, c5, c6);
	if (choice == 6)
		*sum6p = total_digits(6, c1, c2, c3, c4, c5, c6);
	if (choice == 7)
		*threep = three(c1, c2, c3, c4, c5, c6, &dd1, &dd2, &dd3, &dd4, &dd5);
	if (choice == 8)
		*fourp = four(c1, c2, c3, c4, c5, c6, &dd1, &dd2, &dd3, &dd4, &dd5);
	if (choice == 9)
		*fullhousep = fullhouse(c1, c2, c3, c4, c5, c6);
	if (choice == 10)
		*smallstrp = small(c1, c2, c3, c4, c5, c6);
	if (choice == 11)
		*largestrp = large(c1, c2, c3, c4, c5, c6);
	if (choice == 12)
		*yahtzeep = yaht(c1, c2, c3, c4, c5, c6);
	if (choice == 13)
		*chancep = dd1 + dd2 + dd3 + dd4 + dd5;
}

// verifies that three of a kind is reached
int three(int count1, int count2, int count3, int count4, int count5, int count6,
	int *d1, int *d2, int *d3, int *d4, int *d5)
{
	int score = 0;
	if (count1 >= 3)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else if (count2 >= 3)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else if (count3 >= 3)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else if (count4 >= 3)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else if (count5 >= 3)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else if (count6 >= 3)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else
		score = 0;
	return score;
}

// verifies that four of a kind is reached
int four(int count1, int count2, int count3, int count4, int count5, int count6,
	int *d1, int *d2, int *d3, int *d4, int *d5)
{
	int score = 0;
	if (count1 >= 4)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else if (count2 >= 4)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else if (count3 >= 4)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else if (count4 >= 4)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else if (count5 >= 4)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else if (count6 >= 4)
		score = *d1 + *d2 + *d3 + *d4 + *d5;
	else
		score = 0;
	return score;
}

// verifies that yahtzee is reached
int yaht(int count1, int count2, int count3, int count4, int count5, int count6)
{
	int score = 0;
	if (count1 == 5)
		score = 50;
	else if (count2 == 5)
		score = 50;
	else if (count3 == 5)
		score = 50;
	else if (count4 == 5)
		score = 50;
	else if (count5 == 5)
		score = 50;
	else if (count6 == 5)
		score = 50;
	else
		score = 0;
	return score;
}

// verifies that full house is reached
int fullhouse(int count1, int count2, int count3, int count4, int count5, int count6)
{
	int score = 0;
	if ((count1 == 3) && ((count2 == 2) || (count3 == 2) || (count4 == 2) || (count5 == 2) || (count6 == 2)))
		score = 25;
	else if ((count2 == 3) && ((count1 == 2) || (count3 == 2) || (count4 == 2) || (count5 == 2) || (count6 == 2)))
		score = 25;
	else if ((count3 == 3) && ((count2 == 2) || (count1 == 2) || (count4 == 2) || (count5 == 2) || (count6 == 2)))
		score = 25;
	else if ((count4 == 3) && ((count2 == 2) || (count3 == 2) || (count1 == 2) || (count5 == 2) || (count6 == 2)))
		score = 25;
	else if ((count5 == 3) && ((count2 == 2) || (count3 == 2) || (count4 == 2) || (count1 == 2) || (count6 == 2)))
		score = 25;
	else if ((count6 == 3) && ((count2 == 2) || (count3 == 2) || (count4 == 2) || (count5 == 2) || (count1 == 2)))
		score = 25;
	else
		score = 0;
	return score;
}

// verifies that small straight is reached
int small(int count1, int count2, int count3, int count4, int count5, int count6)
{
	int score = 0;
	if ((count1 >= 1) && (count2 >= 1) && (count3 >= 1) && (count4 >= 1))
		score = 30;
	else if ((count5 >= 1) && (count2 >= 1) && (count3 >= 1) && (count4 >= 1))
		score = 30;
	else if ((count5 >= 1) && (count6 >= 1) && (count3 >= 1) && (count4 >= 1))
		score = 30;
	else
		score = 0;
	return score;
}

// verifies that large straight is reached
int large(int count1, int count2, int count3, int count4, int count5, int count6)
{
	int score = 0;
	if ((count1 >= 1) && (count2 >= 1) && (count3 >= 1) && (count4 >= 1) && (count5 >= 1))
		score = 40;
	else if ((count6 >= 1) && (count2 >= 1) && (count3 >= 1) && (count4 >= 1) && (count5 >= 1))
		score = 40;
	else
		score = 0;
	return score;
}

// prints scores of player 1 and player 2 by getting inputs by pointers for each category
void print_scores(int *sum1p, int *sum2p, int *sum3p, int *sum4p, int *sum5p, int *sum6p,
	int *threep, int *fourp, int *fullhousep, int *smallstrp, int *largestrp, int *yahtzeep, int *chancep)
{
	int top = 0, bonus = 0, total = 0;
	printf("1. Sum of 1's: %d\n", *sum1p);
	printf("2. Sum of 2's: %d\n", *sum2p);
	printf("3. Sum of 3's: %d\n", *sum3p);
	printf("4. Sum of 4's: %d\n", *sum4p);
	printf("5. Sum of 5's: %d\n", *sum5p);
	printf("6. Sum of 6's: %d\n", *sum6p);
	printf("7. Three-of-a-kind: %d\n", *threep);
	printf("8. Four-of-a-kind: %d\n", *fourp);
	printf("9. Full house: %d\n", *fullhousep);
	printf("10. Small straight: %d\n", *smallstrp);
	printf("11. Large straight: %d\n", *largestrp);
	printf("12. Yahtzee: %d\n", *yahtzeep);
	printf("13. Chance: %d\n", *chancep);
	top = *sum1p + *sum2p + *sum3p + *sum4p + *sum5p + *sum6p;
	if (top >= 63)
	{
		printf("Bonus: %d\n", top);
		bonus = 35;
		total = *sum1p + *sum2p + *sum3p + *sum4p + *sum5p + *sum6p + *threep + *fourp + *fullhousep + *smallstrp + *largestrp + *yahtzeep + *chancep + bonus;
		printf("Total: %d\n", total);
	}
	else
	{
		printf("Bonus: 0\n");
		bonus = 0;
		total = *sum1p + *sum2p + *sum3p + *sum4p + *sum5p + *sum6p + *threep + *fourp + *fullhousep + *smallstrp + *largestrp + *yahtzeep + *chancep + bonus;
		printf("Total: %d\n", total);
	}
}