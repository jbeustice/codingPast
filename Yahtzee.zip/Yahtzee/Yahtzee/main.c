/*	Name: JBEustice
*	Year: 2013
*	Description: a game of yahtzee between 2 players
*/

#include "header.h"

int main(void)
{
	int sum1 = -1, sum2 = -1, sum3 = -1, sum4 = -1, sum5 = -1, sum6 = -1;
	int three = -1, four = -1, fullhouse = -1, smallstr = -1, largestr = -1, yahtzee = -1, chance = -1;
	int sum1_ = -1, sum2_ = -1, sum3_ = -1, sum4_ = -1, sum5_ = -1, sum6_ = -1;
	int three_ = -1, four_ = -1, fullhouse_ = -1, smallstr_ = -1, largestr_ = -1, yahtzee_ = -1, chance_ = -1;
	int option = 0, i = 0;
	char waiting = '\0';

	while (i<1)
	{
		system("cls");
		option = run();
		if (option == 1)
		{
			printf("The scorecard used for Yahtzee is composed of two sections. A upper section and a lower section. A total of thirteen boxes or thirteen scoring combinations are divided amongst the sections. The upper section consists of boxes that are scored by summing the value of the dice matching the faces of the box. If a player rolls four 3's, then the score placed in the 3's box is the sum of the dice which is 12. Once a player has chosen to score a box, it may not be changed and the combination is no longer in play for future rounds. If the sum of the scores in the upper section is greater than or equal to 63, then 35 more points are added to the players overall score as a bonus. The lower section contains a number of poker like combinations.\n");
			printf("Press a key and Enter to continue . . .");
			while (getchar() == '\n');
		}
		if (option == 2)
		{
			start(&sum1, &sum2, &sum3, &sum4, &sum5, &sum6,
				&three, &four, &fullhouse, &smallstr, &largestr, &yahtzee, &chance,
				&sum1_, &sum2_, &sum3_, &sum4_, &sum5_, &sum6_,
				&three_, &four_, &fullhouse_, &smallstr_, &largestr_, &yahtzee_, &chance_);
		}
		if (option == 3)
		{
			printf("Thanks for playing!\n\n");
			break;
		}
	}
	return 0;
}