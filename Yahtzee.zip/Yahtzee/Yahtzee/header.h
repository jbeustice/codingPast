/*	Name: JBEustice
*	Year: 2013
*	Description: a game of yahtzee between 2 players
*/

#ifndef YAHTZEE
#define YAHTZEE

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

// yahtzee function prototypes
void die_count(int die1, int die2, int die3, int die4, int die5, int *c1, int *c2, int *c3, int *c4, int *c5, int *c6);
int total_digits(int number, int count1, int count2, int count3, int count4, int count5, int count6);
void roll_5(int *die1, int *die2, int *die3, int *die4, int *die5);
int roll_die(void);
void start(int *sum1p, int *sum2p, int *sum3p, int *sum4p, int *sum5p, int *sum6p,
	int *threep, int *fourp, int *fullhousep, int *smallstrp, int *largestrp, int *yahtzeep, int *chancep,
	int *sum1_p, int *sum2_p, int *sum3_p, int *sum4_p, int *sum5_p, int *sum6_p,
	int *three_p, int *four_p, int *fullhouse_p, int *smallstr_p, int *largestr_p, int *yahtzee_p, int *chance_p);
void roll_turns(int *die1, int *die2, int *die3, int *die4, int *die5);
void print_5(int die1, int die2, int die3, int die4, int die5);
void chose_score(int *sum1p, int *sum2p, int *sum3p, int *sum4p, int *sum5p, int *sum6p,
	int *threep, int *fourp, int *fullhousep, int *smallstrp, int *largestrp, int *yahtzeep, int *chancep,
	int *d1, int *d2, int *d3, int *d4, int *d5);
int three(int count1, int count2, int count3, int count4, int count5, int count6,
	int *d1, int *d2, int *d3, int *d4, int *d5);
int four(int count1, int count2, int count3, int count4, int count5, int count6,
	int *d1, int *d2, int *d3, int *d4, int *d5);
int small(int count1, int count2, int count3, int count4, int count5, int count6);
int large(int count1, int count2, int count3, int count4, int count5, int count6);
int fullhouse(int count1, int count2, int count3, int count4, int count5, int count6);
int yaht(int count1, int count2, int count3, int count4, int count5, int count6);
void print_scores(int *sum1p, int *sum2p, int *sum3p, int *sum4p, int *sum5p, int *sum6p,
	int *threep, int *fourp, int *fullhousep, int *smallstrp, int *largestrp, int *yahtzeep, int *chancep);
void display_menu(void);
int valid_option(int option);
int get_option(void);
int run(void);

#endif