/*	Name: JBEustice
*	Year: 2013
*	Description: a game of battleship for 1 player against the computer
*/

#include "header.h"

int main(void)
{
	FILE *output = NULL;
	char board_comp[MAX_ROWS][MAX_COLS], board_player[MAX_ROWS][MAX_COLS], guess_player[MAX_ROWS][MAX_COLS], guess_comp[MAX_ROWS][MAX_COLS];
	output = fopen("battleship.log", "w");
	welcome(board_comp, board_player, guess_comp, guess_player);
	play_game(board_comp, board_player, guess_comp, guess_player, output);
	fclose(output);
}