/*	Name: JBEustice
*	Year: 2013
*	Description: a game of battleship for 1 player against the computer
*/

#ifndef FALL2013	
#define FALL2013

#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>

#define MAX_ROWS 10
#define MAX_COLS 10
#define CARR_SIZE 5
#define BATT_SIZE 4
#define CRU_SIZE 3
#define SUB_SIZE 3
#define DE_SIZE 2

typedef enum Boolean
{
	FALSE, TRUE
} boolean;

typedef struct Stats
{
	int hits;
	int misses;
	int total;
	double percent;
} stats;

void welcome(char board_comp[MAX_ROWS][MAX_COLS], char board_player[MAX_ROWS][MAX_COLS], char guess_comp[MAX_ROWS][MAX_COLS], char guess_player[MAX_ROWS][MAX_COLS]);
void init_game_board(char game_board[MAX_ROWS][MAX_COLS]);
void print_game_board(char game_board[MAX_ROWS][MAX_COLS]);
void gen_direction(char *dir_ptr);
void gen_start_pt(int ship_length, char direction, int *row_ptr, int *col_ptr);
boolean is_valid_placement(char board[][MAX_COLS], int row_pt, int col_pt, char dir, int length);
void rand_place(char game_board[MAX_ROWS][MAX_COLS]);
void place_ship(char game_board[MAX_ROWS][MAX_COLS], int row, int col, char dir, int length, char ship);
void man_or_auto(char game_board[MAX_ROWS][MAX_COLS]);
void man_place(char game_board[MAX_ROWS][MAX_COLS]);
boolean start_pt(int ship_length, char direction, int row, int col);
void play_game(char board_comp[MAX_ROWS][MAX_COLS], char board_player[MAX_ROWS][MAX_COLS], char guess_comp[MAX_ROWS][MAX_COLS], char guess_player[MAX_ROWS][MAX_COLS], FILE *output);
char check_shot(char game_board[MAX_ROWS][MAX_COLS], int row, int col);
void update_board(char ship_board[MAX_ROWS][MAX_COLS], char guess_board[MAX_ROWS][MAX_COLS], int row, int col, char shot);
boolean check_sunk(char ship_board[MAX_ROWS][MAX_COLS], char ship);
int sum_sink(int sink[5]);
char comp_rand_guess(char ship_board[MAX_ROWS][MAX_COLS], int *row, int *col);
void calc_stat(char player[MAX_ROWS][MAX_COLS], char computer[MAX_ROWS][MAX_COLS], FILE *fille);

#endif