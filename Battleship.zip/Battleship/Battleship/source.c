/*	Name: JBEustice
*	Year: 2013
*	Description: a game of battleship for 1 player against the computer
*/

#include "header.h"

// the welcome screen plus initializes all boards and places ships
void welcome(char board_comp[MAX_ROWS][MAX_COLS], char board_player[MAX_ROWS][MAX_COLS], char guess_comp[MAX_ROWS][MAX_COLS], char guess_player[MAX_ROWS][MAX_COLS])
{
	char enter = '\0';
	srand((unsigned int)time(NULL));
	printf("***** Weclcome to Battleship! *****\n\n");
	printf("Game information:\n\n");
	printf("This is a two player game.\n");
	printf("Player1 is you and Player2 is the computer.\n");
	printf("The bow of a ship faces right and up.\n\n");
	printf("Hit enter to start the game! ");
	scanf("%c", &enter);
	system("cls");
	init_game_board(board_comp);
	rand_place(board_comp);
	init_game_board(board_player);
	print_game_board(board_player);
	man_or_auto(board_player);
	init_game_board(guess_comp);
	init_game_board(guess_player);
	system("pause");
}

// this initializes the game board with a - in each spot
void init_game_board(char game_board[MAX_ROWS][MAX_COLS])
{
	int i = 0, j = 0;
	for (i = 0; i<MAX_ROWS; i++)
	{
		for (j = 0; j<MAX_COLS; j++)
		{
			game_board[i][j] = '-';
		}
	}
}

// prints the game board in square
void print_game_board(char game_board[MAX_ROWS][MAX_COLS])
{
	int i = 0, j = 0;
	printf("%3d%2d%2d%2d%2d%2d%2d%2d%2d%2d\n", 0, 1, 2, 3, 4, 5, 6, 7, 8, 9);
	for (i = 0; i<MAX_ROWS; i++)
	{
		printf("%-2d", i);
		for (j = 0; j <= MAX_COLS - 1; j++)
		{
			printf("%c ", game_board[i][j]);
		}
		putchar('\n');
	}
	putchar('\n');
}

// randomly generates direction to place ship on board
void gen_direction(char *dir_ptr)
{
	int result = 0;
	result = rand() % 2;
	switch (result)
	{
	case 0: *dir_ptr = 'h';
		break;
	case 1: *dir_ptr = 'v';
		break;
	}
}

// randomly generates the start point to place ship on board
void gen_start_pt(int ship_length, char direction, int *row_ptr, int *col_ptr)
{
	if (direction == 'h')
	{
		*row_ptr = rand() % 10;
		*col_ptr = (rand() % ((10 - ship_length) + 1));
	}
	else
	{
		*row_ptr = (rand() % ((10 - ship_length) + 1));
		*col_ptr = rand() % 10;
	}
}

// returns whether ship placement is not occupied (TRUE,FALSE)
boolean is_valid_placement(char board[][MAX_COLS], int row_pt, int col_pt, char dir, int length)
{
	boolean is_valid = TRUE;
	int i = 0;
	if (dir == 'h')
	{
		for (i = 0; i<length; i++)
		{
			if ((board[row_pt][col_pt - i] != '-') || (col_pt - i<0))
				is_valid = FALSE;
		}
	}
	else
	{
		for (i = 0; i<length; i++)
		{
			if ((board[row_pt + i][col_pt] != '-') || (row_pt + i>9))
				is_valid = FALSE;
		}
	}
	return is_valid;
}

// randomly places all 5 ships on the game board
void rand_place(char game_board[MAX_ROWS][MAX_COLS])
{
	char direction = '\0';
	int i = 0, row = 0, col = 0;
	boolean valid = FALSE;
	int ship_size[5] = { CARR_SIZE,BATT_SIZE,CRU_SIZE,SUB_SIZE,DE_SIZE };
	char ships[5] = { 'c','b','r','s','d' };
	for (i = 0; i<5; i++)
	{
		while (valid == FALSE)
		{
			gen_direction(&direction);
			gen_start_pt(ship_size[i], direction, &row, &col);
			valid = is_valid_placement(game_board, row, col, direction, ship_size[i]);
		}
		place_ship(game_board, row, col, direction, ship_size[i], ships[i]);
		valid = FALSE;
	}
}

// officially places the ship on the board
void place_ship(char game_board[MAX_ROWS][MAX_COLS], int row, int col, char dir, int length, char ship)
{
	int i = 0;
	if (dir == 'h')
	{
		for (i = 0; i<length; i++)
		{
			game_board[row][col - i] = ship;
		}
	}
	else
	{
		for (i = 0; i<length; i++)
		{
			game_board[row + i][col] = ship;
		}
	}
}

// asks user to manually or auto place ships on boards and places ships on board
void man_or_auto(char game_board[MAX_ROWS][MAX_COLS])
{
	char assign = '\0';
	printf("Would you like the computer to randomly place your ships on the board (y/n)? ");
	scanf(" %c", &assign);
	while ((assign != 'y') && (assign != 'n'))
	{
		printf("Please enter y or n: ");
		scanf(" %c", &assign);
	}
	system("cls");
	if (assign == 'n')
	{
		man_place(game_board);
	}
	else
	{
		rand_place(game_board);
		print_game_board(game_board);
	}
}

// places all 5 ships on board by user specification
void man_place(char game_board[MAX_ROWS][MAX_COLS])
{
	char direction = '\0';
	int i = 0, row = 0, col = 0;
	boolean valid = FALSE;
	int ship_size[5] = { CARR_SIZE,BATT_SIZE,CRU_SIZE,SUB_SIZE,DE_SIZE };
	char ships[5] = { 'c','b','r','s','d' };
	char *boats[5] = { "Carrier","Battleship","Cruiser","Submarine","Destroyer" };
	for (i = 0; i<5; i++)
	{
		print_game_board(game_board);
		if (i != 0)
		{
			printf("Would you like to place the %s vertically or horizontally? ", boats[i]);
			scanf(" %c", &direction);
			printf("Where would you like to place the bow of the %s? ", boats[i]);
			scanf("%d%d", &row, &col);
		}
		else
		{
			printf("Would you like to place the %s vertically or horizontally (example: v)? ", boats[i]);
			scanf(" %c", &direction);
			printf("Where would you like to place the bow of the %s (example: 4 2)? ", boats[i]);
			scanf("%d%d", &row, &col);
		}
		valid = start_pt(ship_size[i], direction, row, col);
		while (valid == FALSE)
		{
			printf("Invalid option. Where would you like to place the bow? ");
			scanf("%d%d", &row, &col);
			valid = start_pt(ship_size[i], direction, row, col);
		}
		place_ship(game_board, row, col, direction, ship_size[i], ships[i]);
		system("cls");
	}
	print_game_board(game_board);
}

// test whether the start point to place ship on board is valid and returns a boolean value
boolean start_pt(int ship_length, char direction, int row, int col)
{
	boolean valid = FALSE;
	if (direction == 'h')
	{
		if (col - ship_length + 1 >= 0)
			valid = TRUE;
	}
	else
	{
		if (row + ship_length - 1 <= 9)
			valid = TRUE;
	}
	if (row>9 || row<0)
		valid = FALSE;
	if (col>9 || col<0)
		valid = FALSE;
	return valid;
}

// takes the 2 boards and plays the whole game of battleship after choosing who goes first; also prints to outfile
void play_game(char board_comp[MAX_ROWS][MAX_COLS], char board_player[MAX_ROWS][MAX_COLS], char guess_comp[MAX_ROWS][MAX_COLS], char guess_player[MAX_ROWS][MAX_COLS], FILE *output)
{
	int first = -1, sink_p1[5] = { 0,0,0,0,0 }, sink_c[5] = { 0,0,0,0,0 };
	int row = 0, col = 0, i = 0;
	char shot = '\0', typeship = '\0', ship_type[5] = { 'c','b','r','s','d' };
	boolean sunk = FALSE, temp = FALSE;
	first = rand() % 2;
	system("cls");
	if (first == 0)
	{
		printf("The computer will go first.\n\n");
		system("pause");
		while ((sum_sink(sink_p1)<5) && (sum_sink(sink_c)<5))
		{
			shot = comp_rand_guess(board_player, &row, &col);
			system("cls");
			if (shot == 'm')
			{
				update_board(board_player, guess_player, row, col, shot);
				print_game_board(board_player);
				printf("%d,%d is a miss!\n", row, col);
				fprintf(output, "Computer: %d,%d \"miss\"\n", row, col);
			}
			else
			{
				typeship = board_player[row][col];
				update_board(board_player, guess_player, row, col, shot);
				print_game_board(board_player);
				printf("%d,%d is a hit!\n", row, col);
				switch (typeship)
				{
				case 'c':
				{
					if (check_sunk(board_player, ship_type[0]) == TRUE)
					{
						printf("The computer sunk your carrier!\n");
						fprintf(output, "Computer: %d,%d \"hit\" Sunk carrier!\n", row, col);
					}
					else
						fprintf(output, "Computer: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 'b':
				{
					if (check_sunk(board_player, ship_type[1]) == TRUE)
					{
						printf("The computer sunk your battleship!\n");
						fprintf(output, "Computer: %d,%d \"hit\" Sunk battleship!\n", row, col);
					}
					else
						fprintf(output, "Computer: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 'r':
				{
					if (check_sunk(board_player, ship_type[2]) == TRUE)
					{
						printf("The computer sunk your cruiser!\n");
						fprintf(output, "Computer: %d,%d \"hit\" Sunk cruiser!\n", row, col);
					}
					else
						fprintf(output, "Computer: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 's':
				{
					if (check_sunk(board_player, ship_type[3]) == TRUE)
					{
						printf("The computer sunk your submarine!\n");
						fprintf(output, "Computer: %d,%d \"hit\" Sunk submarine!\n", row, col);
					}
					else
						fprintf(output, "Computer: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 'd':
				{
					if (check_sunk(board_player, ship_type[4]) == TRUE)
					{
						printf("The computer sunk your destroyer!\n");
						fprintf(output, "Computer: %d,%d \"hit\" Sunk destroyer!\n", row, col);
					}
					else
						fprintf(output, "Computer: %d,%d \"hit\"\n", row, col);
					break;
				}
				}
			}
			for (i = 0; i<5; i++)
			{
				temp = check_sunk(board_player, ship_type[i]);
				if (temp == TRUE)
					sink_p1[i] = 1;
			}
			if (sum_sink(sink_p1) == 5)
			{
				printf("\nThe computer has sunk all your ships! You have failed!\n\n");
				fprintf(output, "\nPlayer1 loses, Computer wins\n\n");
				calc_stat(guess_player, guess_comp, output);
				break;
			}
			i = 0;
			system("pause");
			system("cls");
			print_game_board(guess_comp);
			printf("Enter the cell to shoot: ");
			scanf("%d%d", &row, &col);
			shot = check_shot(board_comp, row, col);
			while (shot == 'g')
			{
				printf("Already guessed. Enter the cell to shoot: ");
				scanf("%d%d", &row, &col);
				shot = check_shot(board_comp, row, col);
			}
			if (shot == 'm')
			{
				printf("%d,%d is a miss!\n", row, col);
				fprintf(output, "Player 1: %d,%d \"miss\"\n", row, col);
				update_board(board_comp, guess_comp, row, col, shot);
			}
			else
			{
				printf("%d,%d is a hit!\n", row, col);
				typeship = board_comp[row][col];
				update_board(board_comp, guess_comp, row, col, shot);
				switch (typeship)
				{
				case 'c':
				{
					if (check_sunk(board_comp, ship_type[0]) == TRUE)
					{
						printf("You sunk the computer's carrier!\n");
						fprintf(output, "Player 1: %d,%d \"hit\" Sunk carrier!\n", row, col);
					}
					else
						fprintf(output, "Player 1: %d,%d \"hit\"\n", row, col);
					break;
				}

				case 'b':
				{
					if (check_sunk(board_comp, ship_type[1]) == TRUE)
					{
						printf("You sunk the computer's battleship!\n");
						fprintf(output, "Player 1: %d,%d \"hit\" Sunk battleship!\n", row, col);
					}
					else
						fprintf(output, "Player 1: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 'r':
				{
					if (check_sunk(board_comp, ship_type[2]) == TRUE)
					{
						printf("You sunk the computer's cruiser!\n");
						fprintf(output, "Player 1: %d,%d \"hit\" Sunk cruiser!\n", row, col);
					}
					else
						fprintf(output, "Player 1: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 's':
				{
					if (check_sunk(board_comp, ship_type[3]) == TRUE)
					{
						printf("You sunk the computer's submarine!\n");
						fprintf(output, "Player 1: %d,%d \"hit\" Sunk submarine!\n", row, col);
					}
					else
						fprintf(output, "Player 1: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 'd':
				{
					if (check_sunk(board_comp, ship_type[4]) == TRUE)
					{
						printf("You sunk the computer's destroyer!\n");
						fprintf(output, "Player 1: %d,%d \"hit\" Sunk destroyer!\n", row, col);
					}
					else
						fprintf(output, "Player 1: %d,%d \"hit\"\n", row, col);
					break;
				}
				}
			}
			for (i = 0; i<5; i++)
			{
				temp = check_sunk(board_comp, ship_type[i]);
				if (temp == TRUE)
					sink_c[i] = 1;
			}
			if (sum_sink(sink_c) == 5)
			{
				printf("\nYou have sunk all of computer's ships! You are victorious!\n\n");
				fprintf(output, "\nPlayer1 wins, Computer loses\n\n");
				calc_stat(guess_player, guess_comp, output);
				break;
			}
			system("pause");
		}
	}
	// -------------------------------------------------------------------------------------------------------------------------------------
	else
	{
		printf("The user will go first.\n\n");
		system("pause");
		while ((sum_sink(sink_p1)<5) && (sum_sink(sink_c)<5))
		{
			system("cls");
			print_game_board(guess_comp);
			printf("Enter the cell to shoot: ");
			scanf("%d%d", &row, &col);
			shot = check_shot(board_comp, row, col);
			while (shot == 'g')
			{
				printf("Already guessed. Enter the cell to shoot: ");
				scanf("%d%d", &row, &col);
				shot = check_shot(board_comp, row, col);
			}
			if (shot == 'm')
			{
				printf("%d,%d is a miss!\n", row, col);
				fprintf(output, "Player 1: %d,%d \"miss\"\n", row, col);
				update_board(board_comp, guess_comp, row, col, shot);
			}
			else
			{
				printf("%d,%d is a hit!\n", row, col);
				typeship = board_comp[row][col];
				update_board(board_comp, guess_comp, row, col, shot);
				switch (typeship)
				{
				case 'c':
				{
					if (check_sunk(board_comp, ship_type[0]) == TRUE)
					{
						printf("You sunk the computer's carrier!\n");
						fprintf(output, "Player 1: %d,%d \"hit\" Sunk carrier!\n", row, col);
					}
					else
						fprintf(output, "Player 1: %d,%d \"hit\"\n", row, col);
					break;
				}

				case 'b':
				{
					if (check_sunk(board_comp, ship_type[1]) == TRUE)
					{
						printf("You sunk the computer's battleship!\n");
						fprintf(output, "Player 1: %d,%d \"hit\" Sunk battleship!\n", row, col);
					}
					else
						fprintf(output, "Player 1: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 'r':
				{
					if (check_sunk(board_comp, ship_type[2]) == TRUE)
					{
						printf("You sunk the computer's cruiser!\n");
						fprintf(output, "Player 1: %d,%d \"hit\" Sunk cruiser!\n", row, col);
					}
					else
						fprintf(output, "Player 1: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 's':
				{
					if (check_sunk(board_comp, ship_type[3]) == TRUE)
					{
						printf("You sunk the computer's submarine!\n");
						fprintf(output, "Player 1: %d,%d \"hit\" Sunk submarine!\n", row, col);
					}
					else
						fprintf(output, "Player 1: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 'd':
				{
					if (check_sunk(board_comp, ship_type[4]) == TRUE)
					{
						printf("You sunk the computer's destroyer!\n");
						fprintf(output, "Player 1: %d,%d \"hit\" Sunk destroyer!\n", row, col);
					}
					else
						fprintf(output, "Player 1: %d,%d \"hit\"\n", row, col);
					break;
				}
				}
			}
			for (i = 0; i<5; i++)
			{
				temp = check_sunk(board_comp, ship_type[i]);
				if (temp == TRUE)
					sink_c[i] = 1;
			}
			if (sum_sink(sink_c) == 5)
			{
				printf("\nYou have sunk all of the computer's ships! You are victorious!\n\n");
				fprintf(output, "\nPlayer1 wins, Computer loses\n\n");
				calc_stat(guess_player, guess_comp, output);
				break;
			}
			i = 0;
			system("pause");
			shot = comp_rand_guess(board_player, &row, &col);
			system("cls");
			if (shot == 'm')
			{
				update_board(board_player, guess_player, row, col, shot);
				print_game_board(board_player);
				printf("%d,%d is a miss!\n", row, col);
				fprintf(output, "Computer: %d,%d \"miss\"\n", row, col);
			}
			else
			{
				typeship = board_player[row][col];
				update_board(board_player, guess_player, row, col, shot);
				print_game_board(board_player);
				printf("%d,%d is a hit!\n", row, col);
				switch (typeship)
				{
				case 'c':
				{
					if (check_sunk(board_player, ship_type[0]) == TRUE)
					{
						printf("The computer sunk your carrier!\n");
						fprintf(output, "Computer: %d,%d \"hit\" Sunk carrier!\n", row, col);
					}
					else
						fprintf(output, "Computer: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 'b':
				{
					if (check_sunk(board_player, ship_type[1]) == TRUE)
					{
						printf("The computer sunk your battleship!\n");
						fprintf(output, "Computer: %d,%d \"hit\" Sunk battleship!\n", row, col);
					}
					else
						fprintf(output, "Computer: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 'r':
				{
					if (check_sunk(board_player, ship_type[2]) == TRUE)
					{
						printf("The computer sunk your cruiser!\n");
						fprintf(output, "Computer: %d,%d \"hit\" Sunk cruiser!\n", row, col);
					}
					else
						fprintf(output, "Computer: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 's':
				{
					if (check_sunk(board_player, ship_type[3]) == TRUE)
					{
						printf("The computer sunk your submarine!\n");
						fprintf(output, "Computer: %d,%d \"hit\" Sunk submarine!\n", row, col);
					}
					else
						fprintf(output, "Computer: %d,%d \"hit\"\n", row, col);
					break;
				}
				case 'd':
				{
					if (check_sunk(board_player, ship_type[4]) == TRUE)
					{
						printf("The computer sunk your destroyer!\n");
						fprintf(output, "Computer: %d,%d \"hit\" Sunk destroyer!\n", row, col);
					}
					else
						fprintf(output, "Computer: %d,%d \"hit\"\n", row, col);
					break;
				}
				}
			}
			for (i = 0; i<5; i++)
			{
				temp = check_sunk(board_player, ship_type[i]);
				if (temp == TRUE)
					sink_p1[i] = 1;
			}
			if (sum_sink(sink_p1) == 5)
			{
				printf("\nThe computer has sunk all your ships! You have failed!\n\n");
				fprintf(output, "\nPlayer1 loses, Computer wins\n\n");
				calc_stat(guess_player, guess_comp, output);
				break;
			}
			system("pause");
		}
	}
}

// checks to see if shot a hit or miss (or already guessed); returns char h,m,g
char check_shot(char game_board[MAX_ROWS][MAX_COLS], int row, int col)
{
	char shot = '\0';
	switch (game_board[row][col])
	{
	case '-':
		shot = 'm';
		break;
	case 'c':
		shot = 'h';
		break;
	case 'b':
		shot = 'h';
		break;
	case 'r':
		shot = 'h';
		break;
	case 's':
		shot = 'h';
		break;
	case 'd':
		shot = 'h';
		break;
	case 'm':
		shot = 'g';
		break;
	case '*':
		shot = 'g';
		break;
	}
	return shot;
}

// updates guessed board to see hits and misses; also replaces ship with h if hit
void update_board(char ship_board[MAX_ROWS][MAX_COLS], char guess_board[MAX_ROWS][MAX_COLS], int row, int col, char shot)
{
	if (shot == 'h')
	{
		ship_board[row][col] = '*';
		guess_board[row][col] = '*';
	}
	if (shot == 'm')
	{
		ship_board[row][col] = 'm';
		guess_board[row][col] = 'm';
	}
}

// checks to see whether a ship is sunk
boolean check_sunk(char ship_board[MAX_ROWS][MAX_COLS], char ship)
{
	int i = 0, j = 0;
	boolean valid = TRUE;
	for (i = 0; i<10; i++)
	{
		for (j = 0; j<10; j++)
		{
			if (ship_board[i][j] == ship)
				valid = FALSE;
		}
	}
	return valid;
}

// counts and returns the number of sunk ships
int sum_sink(int sink[5])
{
	int i = 0, sum = 0;
	for (i = 0; i<5; i++)
	{
		sum += sink[i];
	}
	return sum;
}

// computer randomly guesses a cell to shoot and returns via pointers
char comp_rand_guess(char ship_board[MAX_ROWS][MAX_COLS], int *row, int *col)
{
	char shot = '\0';
	*row = rand() % 9;
	*col = rand() % 9;
	shot = check_shot(ship_board, *row, *col);
	while (shot == 'g')
	{
		*row = rand() % 9;
		*col = rand() % 9;
		shot = check_shot(ship_board, *row, *col);
	}
	return shot;
}

// calculates and sends to outfile all the stats at the end of game for both players; uses the stats struct
void calc_stat(char player[MAX_ROWS][MAX_COLS], char computer[MAX_ROWS][MAX_COLS], FILE *fille)
{
	int i = 0, j = 0, count_h = 0, count_m = 0;
	stats p1, comp;
	for (i = 0; i<MAX_ROWS; i++)
	{
		for (j = 0; j<MAX_COLS; j++)
		{
			if (player[i][j] == '*')
				count_h++;
			if (player[i][j] == 'm')
				count_m++;
		}
	}
	p1.hits = count_h;
	p1.misses = count_m;
	p1.total = count_h + count_m;
	p1.percent = ((double)count_h) / ((double)count_m) * 100;
	fprintf(fille, "\n*** Player 1 Stats ***\n");
	fprintf(fille, "Number of Hits: %d\nNumber of Misses: %d\n", p1.hits, p1.misses);
	fprintf(fille, "Total Shots: %d\nHit/Miss Ratio: %2.0f%%\n", p1.total, p1.percent);
	i = 0;
	j = 0;
	count_h = 0;
	count_m = 0;
	for (i = 0; i<MAX_ROWS; i++)
	{
		for (j = 0; j<MAX_COLS; j++)
		{
			if (computer[i][j] == '*')
				count_h++;
			if (computer[i][j] == 'm')
				count_m++;
		}
	}
	comp.hits = count_h;
	comp.misses = count_m;
	comp.total = count_h + count_m;
	comp.percent = ((double)count_h) / ((double)count_m) * 100;
	fprintf(fille, "\n*** Computer Stats ***\n");
	fprintf(fille, "Number of Hits: %d\nNumber of Misses: %d\n", comp.hits, comp.misses);
	fprintf(fille, "Total Shots: %d\nHit/Miss Ratio: %2.0f%%\n", comp.total, comp.percent);
}