/*	Name: JBEustice
*	Year: 2013
*	Description: a math program for elementary school kids; 5 levels of difficulty; 10 randomly generated problems
*/

#include "header.h"

int main(void)
{
	menu();
}
