/*	Name: JBEustice
*	Year: 2013
*	Description: a math program for elementary school kids; 5 levels of difficulty; 10 randomly generated problems
*/

#include "header.h"

void menu(void)
{
	int choice = 0;
	printf("***Welcome to Math Games***\n\n");
	printf("Please select an option:\n\n");
	printf(" 1. Rules\n 2. Play game!\n 3. Exit\n");
	scanf("%d", &choice);
	switch (choice)
	{
	case 1:
		print_rules();
		system("cls");
		menu();
		break;
	case 2:
		game_menu();
		system("cls");
		menu();
		break;
	default:
		system("cls");
		printf("Thanks for playing!\n\n");
	}
}

// prints rules to game
void print_rules(void)
{
	int c = 0;
	FILE *input;
	system("cls");
	input = fopen("rules.txt", "r");
	while ((c = getc(input)) != EOF)
	{
		putchar(c);
	}
	fclose(input);
	printf("\n\n");
	system("pause");
}

// prints level choices and calls a seperate function for each level to play game
void game_menu(void)
{
	int level = 0, score = 0;
	char name[4];
	FILE *output = NULL;
	output = fopen("score.txt", "w");
	printf("Enter your initials (3 characters): ");
	scanf("%s", name);
	while (strlen(name) != 3)
	{
		printf("Invalid option: Please enter your initials (3 characters): ");
		scanf("%s", name);
	}
	system("cls");
	printf("Which level would you like to play?\n\n");
	printf(" 1. Easy\n 2. Fair\n 3. Intermediate\n 4. Hard\n 5. Impossible\n");
	scanf("%d", &level);
	srand((unsigned)time(NULL));
	if (level == 1)
		score = play_easy();
	else if (level == 2)
		score = play_fair();
	else if (level == 3)
		score = play_inter();
	else if (level == 4)
		score = play_hard();
	else
		score = play_imp();
	printf(" total of %d points!\n\n", score);
	system("pause");
	fprintf(output, "Initials: %s\nScore: %d\n", name, score);
	fclose(output);
}

// generates 10 questions for the easy level and returns score
int play_easy(void)
{
	int i = 1, a = 0, b = 0, c = 0, sign1 = 0, sign2 = 0, correct = 0, answer = 0, points = 0;
	for (i = 1; i <= 10; i++)
	{
		system("cls");
		if (i == 1)
			printf("This is question 1 of 10.\n\n");
		else
			printf("This is question %d of 10. You have answerd %d correctly.\n\n", i, correct);
		a = rand() % 9 + 1;
		b = rand() % 5 + 1;
		sign1 = rand() % 2; // 0 means +, 1 means -
		if ((correct / (double)i)<INCREASE)
		{
			if (sign1 == 0)
			{
				printf("%d + %d = ", a, b);
				scanf("%d", &answer);
				if (answer == a + b)
				{
					points++;
					correct++;
				}
				else
					points--;
			}
			else
			{
				if (a>b)
				{
					printf("%d - %d = ", a, b);
					scanf("%d", &answer);
					if (answer == a - b)
					{
						points++;
						correct++;
					}
					else
						points--;
				}
				else
				{
					printf("%d - %d = ", b, a);
					scanf("%d", &answer);
					if (answer == b - a)
					{
						points++;
						correct++;
					}
					else
						points--;
				}
			}
		}
		else
		{
			c = rand() % 9 + 1;
			sign2 = rand() % 2;
			if ((sign1 == 0) && (sign2 == 0))
			{
				printf("%d + %d + %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a + b + c)
				{
					points += 2;
					correct++;
				}
				else
					points--;
			}
			else if ((sign1 == 0) && (sign1 == 1))
			{
				printf("%d + %d - %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a + b - c)
				{
					points += 2;
					correct++;
				}
				else
					points--;
			}
			else if ((sign1 == 1) && (sign1 == 0))
			{
				printf("%d - %d + %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a - b + c)
				{
					points += 2;
					correct++;
				}
				else
					points--;
			}
			else
			{
				printf("%d - %d - %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a - b - c)
				{
					points += 2;
					correct++;
				}
				else
					points--;
			}
		}
	}
	system("cls");
	printf("You answered %d questions correctly for a", correct);
	return points;
}

// generates 10 questions for the fair level and returns score
int play_fair(void)
{
	int i = 1, a = 0, b = 0, correct = 0, answer = 0, points = 0;
	for (i = 1; i <= 10; i++)
	{
		system("cls");
		if (i == 1)
			printf("This is question 1 of 10.\n\n");
		else
			printf("This is question %d of 10. You have answerd %d correctly.\n\n", i, correct);
		if ((correct / (double)i)<INCREASE)
		{
			a = rand() % 5 + 1;
			b = rand() % 5 + 1;
			printf("%d x %d = ", a, b);
			scanf("%d", &answer);
			if (answer == a * b)
			{
				points++;
				correct++;
			}
			else
				points--;
		}
		else
		{
			a = rand() % 5 + 5;
			b = rand() % 7 + 3;
			printf("%d x %d = ", a, b);
			scanf("%d", &answer);
			if (answer == a * b)
			{
				points += 2;
				correct++;
			}
			else
				points--;
		}
	}
	return points;
}

// generates 10 questions for the intermediate level and returns score
int play_inter(void)
{
	int i = 1, a = 0, b = 0, correct = 0, answer = 0, remainder = 0, points = 0;
	for (i = 1; i <= 10; i++)
	{
		system("cls");
		if (i == 1)
			printf("This is question 1 of 10.\n\n");
		else
			printf("This is question %d of 10. You have answerd %d correctly.\n\n", i, correct);
		if ((correct / (double)i)<INCREASE)
		{
			a = rand() % 5 + 1;
			b = rand() % 5 + 1;
			printf("Enter 2 numbers for answer and remainder (ex: 3 4)\n%d / %d = ", a, b);
			scanf("%d%d", &answer, &remainder);
			if ((answer == a / b) && (remainder == a % b))
			{
				points++;
				correct++;
			}
			else
				points--;
		}
		else
		{
			a = rand() % 4 + 6;
			b = rand() % 9 + 1;
			printf("Enter 2 numbers for answer and remainder (ex: 3 4)\n%d / %d = ", a, b);
			scanf("%d%d", &answer, &remainder);
			if ((answer == a / b) && (remainder == a % b))
			{
				points += 2;
				correct++;
			}
			else
				points--;
		}
	}
	return points;
}

// generates 10 questions for the hard level and returns score
int play_hard(void)
{
	int i = 1, a = 0, b = 0, c = 0, correct = 0, answer = 0, points = 0, choice = 0;
	for (i = 1; i <= 10; i++)
	{
		system("cls");
		if (i == 1)
			printf("This is question 1 of 10.\n\n");
		else
			printf("This is question %d of 10. You have answerd %d correctly.\n\n", i, correct);
		choice = rand() % 6;
		if ((correct / (double)i)<INCREASE)
		{
			a = rand() % 11 - 5;
			b = rand() % 11 - 5;
			c = rand() % 19 - 9;
			switch (choice)
			{
			case 1:
				printf("%d + %d + %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a + b + c)
				{
					points++;
					correct++;
				}
				else
					points--;
				break;
			case 2:
				printf("%d + %d - %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a + b - c)
				{
					points++;
					correct++;
				}
				else
					points--;
				break;
			case 3:
				printf("%d - %d + %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a - b + c)
				{
					points++;
					correct++;
				}
				else
					points--;
				break;
			case 4:
				printf("%d - %d - %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a - b - c)
				{
					points++;
					correct++;
				}
				else
					points--;
				break;
			case 5:
				printf("%d x %d - %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a * b - c)
				{
					points++;
					correct++;
				}
				else
					points--;
				break;
			default:
				printf("%d x %d + %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a * b + c)
				{
					points++;
					correct++;
				}
				else
					points--;
			}
		}
		else
		{
			a = rand() % 19 - 9;
			b = rand() % 19 - 9;
			c = rand() % 19 - 9;
			switch (choice)
			{
			case 1:
				printf("%d x %d + %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a * b + c)
				{
					points += 2;
					correct++;
				}
				else
					points--;
				break;
			case 2:
				printf("%d x %d - %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a * b - c)
				{
					points += 2;
					correct++;
				}
				else
					points--;
				break;
			case 3:
				printf("%d x %d x %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a * b*c)
				{
					points += 2;
					correct++;
				}
				else
					points--;
				break;
			case 4:
				b = rand() % 7 - 3;
				while (b == 0)
				{
					b = rand() % 7 - 3;
				}
				a = b * (rand() % 7 - 3);
				printf("%d / %d - %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a / b - c)
				{
					points += 2;
					correct++;
				}
				else
					points--;
				break;
			case 5:
				b = rand() % 7 - 3;
				while (b == 0)
				{
					b = rand() % 7 - 3;
				}
				a = b * (rand() % 7 - 3);
				printf("%d / %d + %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a / b + c)
				{
					points += 2;
					correct++;
				}
				else
					points--;
				break;
			default:
				b = rand() % 7 - 3;
				while (b == 0)
				{
					b = rand() % 7 - 3;
				}
				a = b * (rand() % 7 - 3);
				printf("%d / %d x %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a / b * c)
				{
					points += 2;
					correct++;
				}
				else
					points--;
			}
		}
	}
	return points;
}

// generates 10 questions for the impossible level and returns score
int play_imp(void)
{
	int i = 1, a = 0, b = 0, c = 0, d = 0, correct = 0, answer = 0, points = 0, choice = 0;
	for (i = 1; i <= 10; i++)
	{
		system("cls");
		if (i == 1)
			printf("This is question 1 of 10.\n\n");
		else
			printf("This is question %d of 10. You have answerd %d correctly.\n\n", i, correct);
		choice = rand() % 7;
		if ((correct / (double)i)<INCREASE)
		{
			a = rand() % 199 - 99;
			while ((a>-10) && (a<10))
			{
				a = rand() % 199 - 99;
			}
			b = rand() % 199 - 99;
			while ((b>-10) && (b<10))
			{
				b = rand() % 199 - 99;
			}
			c = rand() % 199 - 99;
			while ((c>-10) && (c<10))
			{
				c = rand() % 199 - 99;
			}
			switch (choice)
			{
			case 1:
				d = rand() % 199 - 99;
				while ((d>-10) && (d<10))
				{
					d = rand() % 199 - 99;
				}
				printf("%d + %d + %d - %d = ", a, b, c, d);
				scanf("%d", &answer);
				if (answer == a + b + c - d)
				{
					points++;
					correct++;
				}
				else
					points--;
				break;
			case 2:
				d = rand() % 199 - 99;
				while ((d>-10) && (d<10))
				{
					d = rand() % 199 - 99;
				}
				printf("%d - %d + %d - %d= ", a, b, c, d);
				scanf("%d", &answer);
				if (answer == a - b + c - d)
				{
					points++;
					correct++;
				}
				else
					points--;
				break;
			case 3:
				d = rand() % 199 - 99;
				while ((d>-10) && (d<10))
				{
					d = rand() % 199 - 99;
				}
				printf("%d - %d + %d + %d = ", a, b, c, d);
				scanf("%d", &answer);
				if (answer == a - b + c + d)
				{
					points++;
					correct++;
				}
				else
					points--;
				break;
			case 4:
				printf("%d - %d x %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a - b - c)
				{
					points++;
					correct++;
				}
				else
					points--;
				break;
			case 5:
				printf("%d x %d - %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a * b - c)
				{
					points++;
					correct++;
				}
				else
					points--;
				break;
			case 6:
				printf("%d x %d - %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a * b - c)
				{
					points++;
					correct++;
				}
				else
					points--;
				break;
			default:
				printf("%d x %d + %d = ", a, b, c);
				scanf("%d", &answer);
				if (answer == a * b + c)
				{
					points++;
					correct++;
				}
				else
					points--;
			}
		}
		else
		{
			a = rand() % 1999 - 999;
			while ((a>-10) && (a<10))
			{
				a = rand() % 1999 - 999;
			}
			b = rand() % 1999 - 999;
			while ((b>-10) && (b<10))
			{
				b = rand() % 1999 - 999;
			}
			c = rand() % 1999 - 999;
			while ((c>-10) && (c<10))
			{
				c = rand() % 1999 - 999;
			}
			d = rand() % 1999 - 999;
			while ((d>-10) && (d<10))
			{
				d = rand() % 1999 - 999;
			}
			switch (choice)
			{
			case 1:
				printf("%d + %d - %d - %d = ", a, b, c, d);
				scanf("%d", &answer);
				if (answer == a + b - c - d)
				{
					points += 2;
					correct++;
				}
				else
					points--;
				break;
			case 2:
				printf("%d - %d + %d - %d= ", a, b, c, d);
				scanf("%d", &answer);
				if (answer == a - b + c - d)
				{
					points += 2;
					correct++;
				}
				else
					points--;
				break;
			case 3:
				printf("%d - %d x %d + %d = ", a, b, c, d);
				scanf("%d", &answer);
				if (answer == a - b * c + d)
				{
					points += 2;
					correct++;
				}
				else
					points--;
				break;
			case 4:
				printf("%d x %d x %d x %d = ", a, b, c, d);
				scanf("%d", &answer);
				if (answer == a * b*c*d)
				{
					points += 2;
					correct++;
				}
				else
					points--;
				break;
			case 5:
				b = rand() % 63 - 31;
				while ((b>-10) && (b<10))
				{
					b = rand() % 63 - 31;
				}
				a = b * (rand() % 63 - 31);
				while (a == 0)
				{
					a = b * rand() % 63 - 31;
				}
				printf("%d / %d + %d x %d = ", a, b, c, d);
				scanf("%d", &answer);
				if (answer == a / b + c * d)
				{
					points += 2;
					correct++;
				}
				else
					points--;
				break;
			case 6:
				b = rand() % 63 - 31;
				while ((b>-10) && (b<10))
				{
					b = rand() % 63 - 31;
				}
				a = b * (rand() % 63 - 31);
				while (a == 0)
				{
					a = b * rand() % 63 - 31;
				}
				printf("%d / %d - %d - %d = ", a, b, c, d);
				scanf("%d", &answer);
				if (answer == a / b - c - d)
				{
					points += 2;
					correct++;
				}
				else
					points--;
				break;
			default:
				b = rand() % 63 - 31;
				while ((b>-10) && (b<10))
				{
					b = rand() % 63 - 31;
				}
				a = b * (rand() % 63 - 31);
				while (a == 0)
				{
					a = b * rand() % 63 - 31;
				}
				printf("%d / %d x %d x %d = ", a, b, c, d);
				scanf("%d", &answer);
				if (answer == a / b * c*d)
				{
					points += 2;
					correct++;
				}
				else
					points--;
			}
		}
	}
	return points;
}