/*	Name: JBEustice
*	Year: 2013
*	Description: a math program for elementary school kids; 5 levels of difficulty; 10 randomly generated problems
*/

#ifndef FALL2013	
#define FALL2013
#define INCREASE 0.667

#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

// function prototypes
void menu(void);
void print_rules(void);
void game_menu(void);
int play_easy(void);
int play_fair(void);
int play_inter(void);
int play_hard(void);
int play_imp(void);

#endif