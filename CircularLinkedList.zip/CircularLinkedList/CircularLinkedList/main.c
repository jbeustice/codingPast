/*	Name: JBEustice
*	Date: 2014
*	Description: digital music manager; example of a circular linked list
*/

#include "header.h"

int main(void)
{
	printf("Welcome to your ditigal music manager\n\n");
	manager_options();
	return 0;
}