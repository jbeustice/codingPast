/*	Name: JBEustice
*	Date: 2014
*	Description: digital music manager; example of a circular linked list
*/

#include "header.h"

// displays the options and returns the choice made)
int display(void)
{
	int choice = 0;
	printf("What would you like to do?\n");
	printf("	1. Load\n");
	printf("	2. Store\n");
	printf("	3. Display\n");
	printf("	4. Insert\n");
	printf("	5. Delete\n");
	printf("	6. Edit\n");
	printf("	7. Sort\n");
	printf("	8. Rate\n");
	printf("	9. Exit\n");
	scanf("%d", &choice);
	while (choice<1 || choice>9)
	{
		printf("Please enter a valid option.\n");
		scanf("%d", &choice);
	}
	return choice;
}

// continually allows the user to keep choosing the options until 9 (exit) is selected
// each option is completed by calling the appropriate function
void manager_options(void)
{
	int choice = 0;
	Node *record = NULL;
	choice = display();
	while (choice != 9)
	{
		if (choice == 1)
			load_files(&record);
		else if (choice == 2)
			store_files(&record);
		else if (choice == 3)
			display_files(&record);
		else if (choice == 4)
		{
			insert_files(&record);
			sort_files(&record);
		}
		else if (choice == 5)
			delete_files(&record);
		else if (choice == 6)
			edit_files(&record);
		else if (choice == 7)
			sort_files(&record);
		else
			rate_files(&record);
		system("cls");
		choice = display();
	}
	exit_files(&record);
}


// reads records from the last session into a linked list alphabetically by artist
void load_files(Node **files)
{
	FILE *input = NULL;
	Node *newNode = NULL, *pCur = NULL, *pNear = NULL, *pw = NULL;
	Times *newTimes = NULL;
	char *pTemp = NULL, pCopy[75];
	input = fopen("final.txt", "r");
	do
	{
		newNode = (Node *)malloc(sizeof(Node));
		newTimes = (Times *)malloc(sizeof(Times));
		fgets(pCopy, 75, input);
		pTemp = (char *)malloc(sizeof(char)*(strlen(pCopy)));
		strtok(pCopy, "\n");
		newNode->artist = pTemp;
		strcpy(newNode->artist, pCopy);
		fgets(pCopy, 75, input);
		pTemp = (char *)malloc(sizeof(char)*(strlen(pCopy)));
		strtok(pCopy, "\n");
		newNode->album = pTemp;
		strcpy(newNode->album, pCopy);
		fgets(pCopy, 75, input);
		pTemp = (char *)malloc(sizeof(char)*(strlen(pCopy)));
		strtok(pCopy, "\n");
		newNode->song = pTemp;
		strcpy(newNode->song, pCopy);
		fgets(pCopy, 75, input);
		pTemp = (char *)malloc(sizeof(char)*(strlen(pCopy)));
		strtok(pCopy, "\n");
		newNode->genre = pTemp;
		strcpy(newNode->genre, pCopy);
		fscanf(input, "%d", &newTimes->min);
		fscanf(input, "%d", &newTimes->sec);
		newNode->length = newTimes;
		fscanf(input, "%d", &newNode->played);
		fscanf(input, "%d", &newNode->rating);
		newNode->pPrev = NULL;
		newNode->pNext = NULL;

		pCur = *files;
		if (pCur == NULL)
		{
			*files = newNode;
			newNode->pNext = *files;
			newNode->pPrev = *files;
		}
		else if (pCur->pNext == pCur)
		{
			newNode->pNext = pCur;
			newNode->pPrev = pCur;
			pCur->pNext = newNode;
			pCur->pPrev = newNode;
			if (strcmp(newNode->artist, pCur->artist) >= 0)
				*files = pCur;
			else
				*files = newNode;
		}
		else
		{
			do
			{
				pCur = pCur->pNext;
			} while ((strcmp(newNode->artist, pCur->artist) >= 0) && (pCur != *files));
			newNode->pNext = pCur;
			newNode->pPrev = pCur->pPrev;
			pNear = pCur->pPrev;
			pCur->pPrev = newNode;
			pNear->pNext = newNode;
		}
		fgets(pCopy, 75, input);
	} while (!feof(input));
	fclose(input);
}

// prints user choosen record to the file "stored.txt"
void store_files(Node **files)
{
	FILE *output = NULL;
	Node *pCur = NULL;
	int i = 1, choice = 0, j = 1;
	output = fopen("stored.txt", "w");
	if (*files == NULL)
		printf("There are no records to store.\n");
	else
	{
		printf("Which record would you like to store?\n");
		pCur = *files;
		do
		{
			printf("	%d. %s\n", i, pCur->song);
			pCur = pCur->pNext;
			i++;
		} while (pCur != *files);
		scanf("%d", &choice);
		pCur = *files;
		while (j != choice)
		{
			pCur = pCur->pNext;
			j++;
		}
		fprintf(output, "%s\n", pCur->artist);
		fprintf(output, "%s\n", pCur->album);
		fprintf(output, "%s\n", pCur->song);
		fprintf(output, "%s\n", pCur->genre);
		fprintf(output, "%d\n", pCur->length->min);
		fprintf(output, "%d\n", pCur->length->sec);
		fprintf(output, "%d\n", pCur->played);
		fprintf(output, "%d", pCur->rating);
		printf("The record is stored.\n");
	}
	system("pause");
	fclose(output);
}

// displays all records or one record based on a serach field
void display_files(Node **files)
{
	Node *pCur = NULL;
	int i = 1, j = 0, search_int = 0, search_int2 = 0;
	char search_char[75];
	pCur = *files;
	if (*files == NULL)
		printf("There are no records to display.\n");
	else
	{
		system("cls");
		printf("Which records would you like to display?\n");
		printf("	1. All\n");
		printf("	2. Search by Artist\n");
		printf("	3. Search by Album\n");
		printf("	4. Search by Song\n");
		printf("	5. Search by Genre\n");
		printf("	6. Search by Length\n");
		printf("	7. Search by Times Played\n");
		printf("	8. Search by Rating\n");
		scanf("%d", &j);
		while (j<1 || j>8)
		{
			printf("Please enter a valid option.\n");
			scanf("%d\n", &j);
		}
		system("cls");
		if (j == 1)
		{
			do
			{
				printf("RECORD #%d\n", i);
				print_display(&pCur);
				pCur = pCur->pNext;
				i++;
			} while (pCur != *files);
		}
		else if (j == 2)
		{
			printf("Enter artist: \n");
			getchar(); // eats newline character
			gets(search_char);
			while (strcmp(pCur->artist, search_char) != 0)
				pCur = pCur->pNext;
			printf("\nRecord Matched\n");
			print_display(&pCur);
		}
		else if (j == 3)
		{
			printf("Enter album: \n");
			getchar(); // eats newline character
			gets(search_char);;
			while (strcmp(pCur->album, search_char) != 0)
				pCur = pCur->pNext;
			printf("\nRecord Matched\n");
			print_display(&pCur);
		}
		else if (j == 4)
		{
			printf("Enter song: \n");
			getchar(); // eats newline character
			gets(search_char);
			while (strcmp(pCur->song, search_char) != 0)
				pCur = pCur->pNext;
			printf("\nRecord Matched\n");
			print_display(&pCur);
		}
		else if (j == 5)
		{
			printf("Enter genre: \n");
			getchar(); // eats newline character
			gets(search_char);
			while (strcmp(pCur->genre, search_char) != 0)
				pCur = pCur->pNext;
			printf("\nRecord Matched\n");
			print_display(&pCur);
		}
		else if (j == 6)
		{
			printf("Enter min: \n");
			scanf("%d", &search_int);
			printf("Enter sec: \n");
			scanf("%d", &search_int2);
			while ((pCur->length->min != search_int) && (pCur->length->sec != search_int2))
				pCur = pCur->pNext;
			printf("\nRecord Matched\n");
			print_display(&pCur);
		}
		else if (j == 7)
		{
			printf("Enter timed played: \n");
			scanf("%d", &search_int);
			while (pCur->played != search_int)
				pCur = pCur->pNext;
			printf("\nRecord Matched\n");
			print_display(&pCur);
		}
		else
		{
			printf("Enter rating: \n");
			scanf("%d", &search_int);
			while (pCur->rating != search_int)
				pCur = pCur->pNext;
			printf("\nRecord Matched\n");
			print_display(&pCur);
		}
	}
	system("pause");
}

// prints one record to the console
void print_display(Node **files)
{
	Node *pCur = NULL;
	pCur = *files;
	printf("Artist: %s\n", pCur->artist);
	printf("Album: %s\n", pCur->album);
	printf("Song: %s\n", pCur->song);
	printf("Genre: %s\n", pCur->genre);
	printf("Length: %d:%d\n", pCur->length->min, pCur->length->sec);
	printf("Times Played: %d\n", pCur->played);
	printf("Rating: %d\n\n", pCur->rating);
}

// inserts record inputted from user into linked list alphabetically by artist 
void insert_files(Node **files)
{
	Node *newNode = NULL, *pCur = NULL, *pNear = NULL;
	Times *newTimes = NULL;
	char *pTemp = NULL, pCopy[75];
	newNode = (Node *)malloc(sizeof(Node));
	newTimes = (Times *)malloc(sizeof(Times));
	if (newNode != NULL && newTimes != NULL)
	{
		printf("Enter artist:\n");
		getchar(); // eats newline character
		gets(pCopy);
		pTemp = (char *)malloc(sizeof(char)*(strlen(pCopy) + 1));
		newNode->artist = pTemp;
		strcpy(newNode->artist, pCopy);
		printf("Enter album: \n");
		gets(pCopy);
		pTemp = (char *)malloc(sizeof(char)*(strlen(pCopy) + 1));
		newNode->album = pTemp;
		strcpy(newNode->album, pCopy);
		printf("Enter song: \n");
		gets(pCopy);
		pTemp = (char *)malloc(sizeof(char)*(strlen(pCopy) + 1));
		newNode->song = pTemp;
		strcpy(newNode->song, pCopy);
		printf("Enter genre: \n");
		gets(pCopy);
		pTemp = (char *)malloc(sizeof(char)*(strlen(pCopy) + 1));
		newNode->genre = pTemp;
		strcpy(newNode->genre, pCopy);
		printf("Enter min: \n");
		scanf("%d", &newTimes->min);
		printf("Enter sec: \n");
		scanf("%d", &newTimes->sec);
		newNode->length = newTimes;
		printf("Enter times played: \n");
		scanf("%d", &newNode->played);
		printf("Enter rating: \n");
		scanf("%d", &newNode->rating);
		newNode->pPrev = NULL;
		newNode->pNext = NULL;
	}
	pCur = *files;
	if (pCur == NULL)
	{
		*files = newNode;
		newNode->pNext = *files;
		newNode->pPrev = *files;
	}
	else if (pCur->pNext == pCur)
	{
		newNode->pNext = pCur;
		newNode->pPrev = pCur;
		pCur->pNext = newNode;
		pCur->pPrev = newNode;
		if (strcmp(newNode->artist, pCur->artist) >= 0)
			*files = pCur;
		else
			*files = newNode;
	}
	else
	{
		do
		{
			pCur = pCur->pNext;
		} while ((strcmp(newNode->artist, pCur->artist) >= 0) && (pCur != *files));
		newNode->pNext = pCur;
		newNode->pPrev = pCur->pPrev;
		pNear = pCur->pPrev;
		pCur->pPrev = newNode;
		pNear->pNext = newNode;
	}
	system("cls");
}

// deletes a record of the users choosing
void delete_files(Node **files)
{
	Node *pCur = NULL, *pBefore = NULL, *pAfter = NULL;
	int i = 1, choice = 0, j = 1;
	if (*files == NULL)
		printf("There are no records to delete.\n");
	else
	{
		printf("Which record would you like to delete?\n");
		pCur = *files;
		do
		{
			printf("	%d. %s\n", i, pCur->song);
			pCur = pCur->pNext;
			i++;
		} while (pCur != *files);
		scanf("%d", &choice);
		pCur = *files;
		while (j != choice)
		{
			pCur = pCur->pNext;
			j++;
		}
		if (i == 2)
		{
			free(pCur);
			*files = NULL;
		}
		else
		{
			pBefore = pCur->pPrev;
			pAfter = pCur->pNext;
			pBefore->pNext = pAfter;
			pAfter->pPrev = pBefore;
			free(pCur);
			*files = pBefore;
		}
	}
	system("pause");
}

// allows the user to edit any field after choosing the field to search through
void edit_files(Node **files)
{
	Node *pCur = NULL;
	int i = 1, j = 1, option = 0, choice = 0, choice2 = 0;
	char *pTemp = NULL, search[75];
	pCur = *files;
	if (*files == NULL)
		printf("There are no records to edit.\n");
	else
	{
		system("cls");
		printf("How would you like to search for a record to edit?\n");
		printf("	1. Search by Artist\n");
		printf("	2. Search by Album\n");
		printf("	3. Search by Song\n");
		printf("	4. Search by Genre\n");
		printf("	5. Search by Length\n");
		printf("	6. Search by Times Played\n");
		printf("	7. Search by Rating\n");
		scanf("%d", &option);
		while (option<1 || option>7)
		{
			printf("Please enter a valid option.\n");
			scanf("%d\n", &j);
		}
		system("cls");
		printf("Which record would you like to edit?\n");
		if (option == 1)
		{
			do
			{
				printf("	%d. %s\n", i, pCur->artist);
				pCur = pCur->pNext;
				i++;
			} while (pCur != *files);
			scanf("%d", &choice);
		}
		else if (option == 2)
		{
			do
			{
				printf("	%d. %s\n", i, pCur->album);
				pCur = pCur->pNext;
				i++;
			} while (pCur != *files);
			scanf("%d", &choice);
		}
		else if (option == 3)
		{
			do
			{
				printf("	%d. %s\n", i, pCur->song);
				pCur = pCur->pNext;
				i++;
			} while (pCur != *files);
			scanf("%d", &choice);
		}
		else if (option == 4)
		{
			do
			{
				printf("	%d. %s\n", i, pCur->genre);
				pCur = pCur->pNext;
				i++;
			} while (pCur != *files);
			scanf("%d", &choice);
		}
		else if (option == 5)
		{
			do
			{
				printf("	%d. %d:%d\n", i, pCur->length->min, pCur->length->sec);
				pCur = pCur->pNext;
				i++;
			} while (pCur != *files);
			scanf("%d", &choice);
		}
		else if (option == 6)
		{
			do
			{
				printf("	%d. %d\n", i, pCur->played);
				pCur = pCur->pNext;
				i++;
			} while (pCur != *files);
			scanf("%d", &choice);
		}
		else
		{
			do
			{
				printf("	%d. %d\n", i, pCur->rating);
				pCur = pCur->pNext;
				i++;
			} while (pCur != *files);
			scanf("%d", &choice);
		}
		system("cls");
		printf("Here is the record.\n");
		while (j != choice)
		{
			pCur = pCur->pNext;
			j++;
		}
		print_display(&pCur);
		printf("\nWhich field would you like to edit?\n");
		printf("	1. Artist\n");
		printf("	2. Album\n");
		printf("	3. Song\n");
		printf("	4. Genre\n");
		printf("	5. Length\n");
		printf("	6. Times Played\n");
		printf("	7. Rating\n");
		scanf("%d", &choice2);
		if (choice2 == 1)
		{
			printf("Enter edited artist:\n");
			getchar(); // eats newline character
			gets(search);
			pTemp = (char *)malloc(sizeof(char)*(strlen(search) + 1));
			pCur->artist = pTemp;
			strcpy(pCur->artist, search);
		}
		else if (choice2 == 2)
		{
			printf("Enter edited album:\n");
			getchar();
			gets(search);
			pTemp = (char *)malloc(sizeof(char)*(strlen(search) + 1));
			pCur->album = pTemp;
			strcpy(pCur->album, search);
		}
		else if (choice2 == 3)
		{
			printf("Enter edited song:\n");
			getchar();
			gets(search);
			pTemp = (char *)malloc(sizeof(char)*(strlen(search) + 1));
			pCur->song = pTemp;
			strcpy(pCur->song, search);
		}
		else if (choice2 == 4)
		{
			printf("Enter edited genre:\n");
			getchar();
			gets(search);
			pTemp = (char *)malloc(sizeof(char)*(strlen(search) + 1));
			pCur->genre = pTemp;
			strcpy(pCur->genre, search);
		}
		else if (choice2 == 5)
		{
			printf("Enter edited minutes:\n");
			scanf("%d", &pCur->length->min);
			printf("Enter edited seconds:\n");
			scanf("%d", &pCur->length->sec);
		}
		else if (choice2 == 6)
		{
			printf("Enter edited time played:\n");
			scanf("%d", &pCur->played);
		}
		else
		{
			printf("Enter edited rating:\n");
			scanf("%d", &pCur->rating);
		}
	}
	system("pause");
}

// sorts the records alphabetically or numerically based on user chosen field
void sort_files(Node **files)
{
	int choice = 0, i = 0;
	Node *pCur = NULL, *pComp = NULL, *pTemp = NULL, *pEnd = NULL, *pStart = NULL, *pSort1 = NULL, *pSort4 = NULL, *pNear = NULL;
	if (*files != NULL)
	{
		pCur = *files;
		pComp = pCur->pNext;
		do
		{
			pCur = pCur->pNext;
			i++;
		} while (pCur != *files);
		pCur = *files;
		if (i>1)
		{
			printf("How would you like to sort the records?\n");
			printf("	1. Artist\n");
			printf("	2. Album\n");
			printf("	3. Song\n");
			printf("	4. Genre\n");
			printf("	5. Length\n");
			printf("	6. Times Played\n");
			printf("	7. Rating\n");
			scanf("%d", &choice);
			while (choice<1 || choice>7)
			{
				printf("Please enter a valid option.\n");
				scanf("%d", &choice);
			}
			if (i == 2) // 2 records
			{
				if (choice == 1)
				{
					if (strcmp(pCur->artist, pComp->artist) >= 0)
						*files = pComp;
				}
				else if (choice == 2)
				{
					if (strcmp(pCur->album, pComp->album) >= 0)
						*files = pComp;
				}
				else if (choice == 3)
				{
					if (strcmp(pCur->song, pComp->song) >= 0)
						*files = pComp;
				}
				else if (choice == 4)
				{
					if (strcmp(pCur->genre, pComp->genre) >= 0)
						*files = pComp;
				}
				else if (choice == 5)
				{
					if (pCur->length->min >= pComp->length->min)
						*files = pComp;
					if ((pCur->length->min == pComp->length->min) && (pCur->length->sec >= pComp->length->sec))
						*files = pComp;
				}
				else if (choice == 6)
				{
					if (pCur->played >= pComp->played)
						*files = pComp;
				}
				else
				{
					if (pCur->rating >= pComp->rating)
						*files = pComp;
				}
			}
			else // more than 2 records
			{
				for (pEnd = pCur->pPrev; pEnd->pNext != *files; pEnd = pEnd->pPrev)
				{
					for (pStart = pCur; pStart != pEnd; pStart->pNext)
					{
						if (choice == 1)
						{
							if (strcmp(pCur->artist, pComp->artist) >= 0)
							{
								pSort1 = pCur->pPrev;
								pSort4 = pComp->pNext;
								pSort1->pNext = pComp;
								pSort4->pPrev = pCur;
								pCur->pNext = pSort4;
								pCur->pPrev = pComp;
								pComp->pNext = pCur;
								pComp->pPrev = pSort1;
							}
						}
						else if (choice == 2)
						{
							if (strcmp(pCur->album, pComp->album) >= 0)
							{
								pSort1 = pCur->pPrev;
								pSort4 = pComp->pNext;
								pSort1->pNext = pComp;
								pSort4->pPrev = pCur;
								pCur->pNext = pSort4;
								pCur->pPrev = pComp;
								pComp->pNext = pCur;
								pComp->pPrev = pSort1;
							}
						}
						else if (choice == 3)
						{
							if (strcmp(pCur->song, pComp->song) >= 0)
							{
								pSort1 = pCur->pPrev;
								pSort4 = pComp->pNext;
								pSort1->pNext = pComp;
								pSort4->pPrev = pCur;
								pCur->pNext = pSort4;
								pCur->pPrev = pComp;
								pComp->pNext = pCur;
								pComp->pPrev = pSort1;
							}
						}
						else if (choice == 4)
						{
							if (strcmp(pCur->genre, pComp->genre) >= 0)
							{
								pSort1 = pCur->pPrev;
								pSort4 = pComp->pNext;
								pSort1->pNext = pComp;
								pSort4->pPrev = pCur;
								pCur->pNext = pSort4;
								pCur->pPrev = pComp;
								pComp->pNext = pCur;
								pComp->pPrev = pSort1;
							}
						}
						else if (choice == 5)
						{
							if (pCur->length->min >= pComp->length->min)
							{
								pSort1 = pCur->pPrev;
								pSort4 = pComp->pNext;
								pSort1->pNext = pComp;
								pSort4->pPrev = pCur;
								pCur->pNext = pSort4;
								pCur->pPrev = pComp;
								pComp->pNext = pCur;
								pComp->pPrev = pSort1;
							}
							if ((pCur->length->min == pComp->length->min) && (pCur->length->sec >= pComp->length->sec))
							{
								pSort1 = pCur->pPrev;
								pSort4 = pComp->pNext;
								pSort1->pNext = pComp;
								pSort4->pPrev = pCur;
								pCur->pNext = pSort4;
								pCur->pPrev = pComp;
								pComp->pNext = pCur;
								pComp->pPrev = pSort1;
							}
						}
						else if (choice == 6)
						{
							if (pCur->played >= pComp->played)
							{
								pSort1 = pCur->pPrev;
								pSort4 = pComp->pNext;
								pSort1->pNext = pComp;
								pSort4->pPrev = pCur;
								pCur->pNext = pSort4;
								pCur->pPrev = pComp;
								pComp->pNext = pCur;
								pComp->pPrev = pSort1;
							}
						}
						else
						{
							if (pCur->rating >= pComp->rating)
							{
								pSort1 = pCur->pPrev;
								pSort4 = pComp->pNext;
								pSort1->pNext = pComp;
								pSort4->pPrev = pCur;
								pCur->pNext = pSort4;
								pCur->pPrev = pComp;
								pComp->pNext = pCur;
								pComp->pPrev = pSort1;
							}
						}
					}
				}
			}
		}
		printf("The records are sorted.\n");
	}
	else
		printf("Cannot sort. You need at least 2 records to sort.\n");
	system("pause");
}

// allows user to rate a chosen song
void rate_files(Node **files)
{
	Node *pCur = NULL;
	int i = 1, j = 1, choice = 0;
	pCur = *files;
	printf("Which song would you like to rate?\n");
	do
	{
		printf("	%d. %s\n", i, pCur->song);
		pCur = pCur->pNext;
		i++;
	} while (pCur != *files);
	scanf("%d", &choice);
	while (j != choice)
	{
		pCur = pCur->pNext;
		j++;
	}
	printf("What would you like to rate the song (1-lowest to 5-highest)?\n");
	scanf("%d", &pCur->rating);
}

// prints all the records to a file
void exit_files(Node **files)
{
	FILE *output = NULL;
	Node *pCur = NULL;
	int i = 1, j = 1;
	output = fopen("final.txt", "w");
	pCur = *files;
	if (pCur != NULL)
	{
		do
		{
			fprintf(output, "%s\n", pCur->artist);
			fprintf(output, "%s\n", pCur->album);
			fprintf(output, "%s\n", pCur->song);
			fprintf(output, "%s\n", pCur->genre);
			fprintf(output, "%d\n", pCur->length->min);
			fprintf(output, "%d\n", pCur->length->sec);
			fprintf(output, "%d\n", pCur->played);
			if (pCur->pNext != *files)
				fprintf(output, "%d\n", pCur->rating);
			else
				fprintf(output, "%d", pCur->rating);
			pCur = pCur->pNext;
		} while (pCur != *files);
	}
	fclose(output);
}