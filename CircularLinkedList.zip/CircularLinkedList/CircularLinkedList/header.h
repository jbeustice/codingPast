/*	Name: JBEustice
*	Date: 2014
*	Description: digital music manager; example of a circular linked list
*/

#ifndef FALL2014	
#define FALL2014

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct times
{
	int min, sec;
} Times;

typedef struct node
{
	char *artist, *album, *song, *genre;
	Times *length;
	int played, rating;
	struct node *pPrev, *pNext;
} Node;

// function prototypes
int display(void);
void manager_options(void);
void load_files(Node **files);
void store_files(Node **files);
void display_files(Node **files);
void print_display(Node **files);
void insert_files(Node **files);
void delete_files(Node **files);
void edit_files(Node **files);
void sort_files(Node **files);
void rate_files(Node **files);
void exit_files(Node **files);

#endif