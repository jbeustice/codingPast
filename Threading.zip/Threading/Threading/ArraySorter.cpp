/*	Name: JBEustice
*	Year: 2015
*	Description: runs different sorting algorithms (insertion, heap, quick, merge) concurrently via threads
*/

#include "ArraySorter.h"

ArraySorter::ArraySorter(void)
{
}

// calls InsertionSortGap with gap=1
void ArraySorter::InsertionSort(int* arr, int n)
{
	InsertionSortGap(arr, n, 0, 1);
	if (IsSorted(arr, n))
	{
		cout << "Insertion sort complete. ";
	}
}

// sorts via insertion sort (if gap=1) or shell sort otherwise
void ArraySorter::InsertionSortGap(int* arr, int n, int startIndex, int gap)
{
	int i = startIndex;
	int temp = 0, j = 0;
	while (i + gap<n)
	{
		j = i + gap;
		while ((j - gap >= startIndex) && (arr[j] < arr[j - gap]))
		{
			temp = arr[j];
			arr[j] = arr[j - gap];
			arr[j - gap] = temp;
			j -= gap;
		}
		i += gap;
	}
}

// Checks to see if the array is in sorted order
bool ArraySorter::IsSorted(int* arr, int n)
{
	for (int i = 1; i < n; i++)
	{
		if (arr[i] < arr[i - 1])
		{
			return false;
		}
	}
	return true;
}

// calls MergeSortRecursive
void ArraySorter::MergeSort(int* arr, int n)
{
	int* temp = new int[n + 1]; // temp array to hold sorted items
								// more efficient than creating and deleting an array in MergeSorted
	MergeSortRecursive(arr, temp, 0, n - 1);
	delete[]temp;
	if (IsSorted(arr, n))
	{
		cout << "Merge sort complete. ";
	}
}

// "splits" original array; calls MergeSorted to do the acutal sorting
void ArraySorter::MergeSortRecursive(int *original, int* temp, int start, int end)
{
	if (start<end) // more than one item
	{
		int mid = (start + end) / 2;
		MergeSortRecursive(original, temp, start, mid); // left half
		MergeSortRecursive(original, temp, mid + 1, end); // right half
		MergeSorted(original, temp, start, mid, end);
	}
}

// sorts the original array from index start to index end
void ArraySorter::MergeSorted(int* original, int* temp, int start, int mid, int end)
{
	int i = start, j = mid + 1, k = 0;
	while (i <= mid && j <= end) // sorts from index start to end
	{
		if (original[i]<original[j])
		{
			temp[k] = original[i];
			i++;
		}
		else
		{
			temp[k] = original[j];
			j++;
		}
		k++;
	}
	if (i <= mid) // copies remaining items from "unfinished" array
	{
		do
		{
			temp[k] = original[i];
			i++;
			k++;
		} while (i <= mid);
	}
	else
	{
		do
		{
			temp[k] = original[j];
			j++;
			k++;
		} while (j <= end);
	}
	for (int m = start; m <= end; m++) // copies sorted temp array back to the original
	{
		original[m] = temp[m];
	}
}

// calls QuickSortRecursive
void ArraySorter::QuickSort(int* arr, int n)
{
	QuickSortRecursive(arr, 0, n - 1);
	if (IsSorted(arr, n))
	{
		cout << "Quick sort complete. ";
	}
}

// "splits" array; calls QuickPivotSort to do the actual sorting
void ArraySorter::QuickSortRecursive(int *arr, int start, int end)
{
	if (end - start > 1)
	{
		int middle = QuickPivotSort(arr, start, end);
		QuickSortRecursive(arr, start, middle - 1); // left half
		QuickSortRecursive(arr, middle + 1, end); // right half
	}
}

// determins the median of 3 values and sorts (larger or smaller) based on the pivot
int ArraySorter::QuickPivotSort(int* arr, int start, int end)
{
	int mid = (start + end) / 2, temp = 0;
	if (arr[start]<arr[mid]) // chooses pivot and places at end of array (no change if already at end)
	{
		if (arr[mid]<arr[end])
		{
			temp = arr[end];
			arr[end] = arr[mid];
			arr[mid] = temp;
		}
		else if (arr[end]<arr[start])
		{
			temp = arr[end];
			arr[end] = arr[start];
			arr[start] = temp;
		}
	}
	else // arr[mid]<=arr[start]
	{
		if (arr[start]<arr[end])
		{
			temp = arr[end];
			arr[end] = arr[start];
			arr[start] = temp;
		}
		else if (arr[end]<arr[mid])
		{
			temp = arr[end];
			arr[end] = arr[mid];
			arr[mid] = temp;
		}
	}
	int pivot = end;
	end--;
	while (start != end) // sorts array based on larger/smaller than pivot
	{
		if (arr[end]<arr[pivot])
		{
			temp = arr[end];
			arr[end] = arr[start];
			arr[start] = temp;
			start++;
		}
		else
			end--;
	}
	// place pivot in correct place in array
	if (arr[end]<arr[pivot])
		end++;
	temp = arr[end];
	arr[end] = arr[pivot];
	arr[pivot] = temp;
	return end;
}