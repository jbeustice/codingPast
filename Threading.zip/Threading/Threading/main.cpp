/*	Name: JBEustice
*	Year: 2015
*	Description: runs different sorting algorithms (insertion, heap, quick, merge) concurrently via threads
*/

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <thread>
#include "ArraySorter.h"
#include "PQ_Heap.h"

using std::cout;
using std::cin;
using std::endl;
using std::thread;

// Generates an array with random numbers in the range [0,1000]
int* GenArr(int count)
{
	int* arr = new int[count];
	for (int i = 0; i < count; i++)
	{
		arr[i] = rand() % 1001;
	}
	return arr;
}

// makes duplicate array
int* CopyArr(int* original, int count)
{
	int* arr = new int[count];
	for (int i = 0; i < count; i++)
	{
		arr[i] = original[i];
	}
	return arr;
}

int main(int argc, char* argv[])
{
	// Seed the random number generator
	srand(time(NULL));

	int count = 50000;
	int* numOriginal = GenArr(count);

	// Create the sorter object
	ArraySorter uno;
	PQ_Heap<int> dos(2);
	ArraySorter tres;
	ArraySorter quattro;

	while (true)
	{
		// Ask for an action
		cout << "Choose an option:" << endl;
		cout << "  1 = Threaded Sorts (insertion, heap, quick, merge)" << endl;
		cout << "  2 = quit" << endl;
		cout << "  ";
		int opt = -1;
		cin >> opt;
		while (opt < 1 || opt > 2)
		{
			cout << "Invalid option. Please choose a valid option:" << endl;
			cout << "  1 = Threaded Sorts (insertion, heap, quick, merge)" << endl;
			cout << "  2 = quit" << endl;
			cout << "  ";
			cin >> opt;
		}

		// terminate program
		if (2 == opt)
		{
			return 0;
		}

		// copy original array for each sorting function
		int* num1 = CopyArr(numOriginal, count);
		int* num2 = CopyArr(numOriginal, count);
		int* num3 = CopyArr(numOriginal, count);
		int* num4 = CopyArr(numOriginal, count);

		// concurrently run sorting functions
		thread* Insertion = new thread(&ArraySorter::InsertionSort, &uno, num1, count);
		thread* Heap = new thread(&PQ_Heap<int>::HeapSort, &dos, num2, count);
		thread* Quick = new thread(&ArraySorter::QuickSort, &tres, num3, count);
		thread* Merge = new thread(&ArraySorter::MergeSort, &quattro, num4, count);

		// wait for all sorting functions to finish
		Insertion->join();
		Heap->join();
		Quick->join();
		Merge->join();

		cout << endl << endl;

		// free memory
		delete Insertion;
		delete Heap;
		delete Quick;
		delete Merge;
		delete[] num1;
		delete[] num2;
		delete[] num3;
		delete[] num4;

	}
	delete[] numOriginal;
	return 0;
}