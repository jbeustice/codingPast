/*	Name: JBEustice
*	Year: 2015
*	Description: runs different sorting algorithms (insertion, heap, quick, merge) concurrently via threads
*/

#ifndef PQHEAP_H
#define PQHEAP_H

#include <queue>
#include <iostream>
#include <stdlib.h>

using std::cout;
using std::endl;

template <typename T>
class PQ_Heap
{
private:
	T * mValues;
	int mK;
	int mUsed;
	int mAllocSize;

	// increases the size of the array (heap)
	void IncreaseSize()
	{
		int newSize = mAllocSize * 2;
		T* newArr = new T[newSize];
		for (int i = 0; i < mAllocSize; i++)
		{
			newArr[i] = mValues[i];
		}
		delete[] mValues;
		mValues = newArr;
		mAllocSize = newSize;
	}

	// sifts new value up the heap to proper position
	void SiftUp(int itemIndex)
	{
		int parent = (itemIndex - 1) / mK;
		while (parent >= 0 && itemIndex > 0) // follows value up heap
		{
			if (mValues[itemIndex] <= mValues[parent])
			{
				break; // in correct position
			}
			// swap values
			T hold = mValues[parent];
			mValues[parent] = mValues[itemIndex];
			mValues[itemIndex] = hold;
			itemIndex = parent;
			parent = (itemIndex - 1) / mK;
		}
	}

	// sifts root value down heap
	void SiftDown()
	{
		int index = 0;
		while (!IsLeaf(index))
		{
			int child = MaxChild(index);
			if (mValues[index] < mValues[child]) // swap values if true
			{
				T hold = mValues[index];
				mValues[index] = mValues[child];
				mValues[child] = hold;
				index = child;
			}
			else // value in correct position
			{
				break;
			}
		}
	}

	// determins max child value for passed argument
	int MaxChild(int itemIndex)
	{
		int firstChild = mK * itemIndex + 1;
		int maxIndex = firstChild;
		// compares children if they exist
		for (int i = firstChild + 1; i<firstChild + mK && i <= mUsed; i++)
		{
			if (mValues[i] > mValues[maxIndex])
			{
				maxIndex = i;
			}
		}
		return maxIndex;
	}

	// determins whether value is a leaf
	bool IsLeaf(int itemIndex)
	{
		if (mUsed >= (mK*itemIndex + 1))
		{
			return false;
		}
		return true;
	}

public:
	// constructor
	PQ_Heap(int k)
	{
		mK = k;
		mAllocSize = k;
		mUsed = -1;
		mValues = new T[k];
	}

	// destructor
	~PQ_Heap()
	{
		delete[] mValues;
	}

	// adds value to heap and sifts appropriately
	void Add(const T& toCopyAndAdd)
	{
		T newValue = toCopyAndAdd;
		mUsed++;
		if (mUsed + 1 > mAllocSize)
		{
			IncreaseSize();
		}
		mValues[mUsed] = newValue;
		SiftUp(mUsed);
	}

	// adds array of items and sorts via RemoveMax function
	void HeapSort(T* arr, int count)
	{
		for (int i = 0; i < count; i++)
		{
			Add(arr[i]);
		}
		for (int j = 1; j < count; j++)
		{
			RemoveMax();
		}
		if (IsSorted(count))
		{
			cout << "Heap sort comlete. ";
		}
	}

	// determins whether heap is empty
	bool IsEmpty() const
	{
		if (mUsed < 0)
		{
			return true;
		}
		return false;
	}

	// removes the max value (arr[0]) and sifts heap appropriately
	void RemoveMax()
	{
		T max = mValues[0];
		mValues[0] = mValues[mUsed];
		mValues[mUsed] = max;
		mUsed--;
		SiftDown();
	}

	// Checks to see if the array is in sorted order
	bool IsSorted(int n)
	{
		for (int i = 1; i < n; i++)
		{
			if (mValues[i] < mValues[i - 1])
			{
				return false;
			}
		}
		return true;
	}
};
#endif