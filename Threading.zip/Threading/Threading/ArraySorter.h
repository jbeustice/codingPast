/*	Name: JBEustice
*	Year: 2015
*	Description: runs different sorting algorithms (insertion, heap, quick, merge) concurrently via threads
*/

#ifndef ARRAYSORTER_H
#define ARRAYSORTER_H

#include <iostream>
#include <stdlib.h>

using std::cout;
using std::endl;

class ArraySorter
{
private:
	void MergeSorted(int* original, int* temp, int start, int mid, int end);
	void MergeSortRecursive(int *original, int* temp, int start, int end);
	void QuickSortRecursive(int *arr, int start, int end);
	int QuickPivotSort(int* arr, int start, int end);

public:
	ArraySorter(void);
	void InsertionSortGap(int* arr, int n, int startIndex, int gap);
	void InsertionSort(int* arr, int n);
	void MergeSort(int* arr, int n);
	void QuickSort(int* arr, int n);

	// Utility function that's implemented for you to verify that an 
	// array is in correct sorted order.
	static bool IsSorted(int* arr, int n);

	void Swap(int& a, int &b)
	{
		int temp = a;
		a = b;
		b = temp;
	};
};

#endif